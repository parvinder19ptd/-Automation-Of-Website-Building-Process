import React from 'react';

const Sidebar = () => {
//   const handleAddText = () => {
//     // Add text functionality
//   };

//   const handleAddImage = () => {
//     // Add image functionality
//   };

  return (
    <aside style={{ maxWidth: '98%', backgroundColor: '#f4f4f4', padding: '1rem' }}>
    </aside>
  );
}

const buttonStyle = {
  display: 'block',
  width: '100%',
  padding: '0.5rem',
  marginBottom: '0.5rem',
  backgroundColor: '#007bff',
  color: 'white',
  border: 'none',
  borderRadius: '4px',
  cursor: 'pointer'
};

export default Sidebar;
